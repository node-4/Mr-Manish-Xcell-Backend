// const MSG91_AUTH_KEY = "392665AOfokrdImEwF64130f11P1";
// const MSG91_SENDER_ID = "xcells";
// const MSG91_ROUTE = 4; // Promotional route
// const MSG91_TEMPLATE_ID = "642d4650d6fc05442345a532";
// // const axios = require("axios");
// function sendSMS1(to, message) {
//     const url = "https://control.msg91.com/api/v5/flow/";
//     const headers = {
//         "Content-Type": "application/json",
//         Authorization: `Bearer ${MSG91_AUTH_KEY}`,
//     };
//     const body = {
//         sender: MSG91_SENDER_ID,
//         route: MSG91_ROUTE,
//         template_id: MSG91_TEMPLATE_ID,
//         country: "91", // India country code
//         message: message,
//         mobiles: "91" + to,
//     };
//     return axios
//         .post(url, body, { headers: headers })
//         .then((res) => res.data)
//         .then((data) => {
//             console.log(data);
//             return data;
//         })
//         .catch((err) => {
//             console.error(err);
//             return { type: "error", message: err.message };
//         });
// }
// const sendSMS = async (to, message) => {
//     const mobileNumber = "";
//     const countryCode = "91";
//     const templateId = "123456";
//     const authKey = "392665Az5aG03qBc5642d4be5P1";

//     const url = "https://api.msg91.com/api/v5/otp";

//     const data = {
//         mobile: "9358122205",
//         country: "91",
//         template_id: "643529ffd6fc0516707bd874",
//         message: "9988",
//     };

//     const config = {
//         headers: {
//             "Content-Type": "application/json",
//             authkey: authKey,
//         },
//     };

//     return await axios
//         .post(url, data, config)
//         .then((response) => {
//             console.log(response.data);
//         })
//         .catch((error) => {
//             console.log(error);
//         });
// };
// module.exports = sendSMS;
